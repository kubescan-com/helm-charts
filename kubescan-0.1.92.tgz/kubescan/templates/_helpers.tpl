{{/*
Shared helpers for the KubeScan chart.
*/}}

{{/*
kubescan.tlsMode resolves the effective TLS mode.

  generate       — the chart mints a CA and an mTLS key pair for Forge and
                   Sentinel. Existing Secrets are reused on upgrade so
                   certificates do not rotate underneath running pods.
  existingSecret — the operator supplies Secrets (cert-manager, corporate
                   PKI). This is the recommended production path.
  insecure       — no TLS. Development only.

`insecure: true` remains supported for backwards compatibility and maps to
the insecure mode.
*/}}
{{- define "kubescan.tlsMode" -}}
{{- if .Values.insecure -}}
insecure
{{- else -}}
{{- .Values.tls.mode | default "generate" -}}
{{- end -}}
{{- end -}}

{{/*
kubescan.forgeTLSSecret is the Secret name holding Forge's server keypair.
*/}}
{{- define "kubescan.forgeTLSSecret" -}}
{{- if and .Values.tls.existingSecret.forge (eq (include "kubescan.tlsMode" .) "existingSecret") -}}
{{- .Values.tls.existingSecret.forge -}}
{{- else -}}
kubescan-forge-tls
{{- end -}}
{{- end -}}

{{/*
kubescan.sentinelTLSSecret is the Secret name holding Sentinel's client keypair.
*/}}
{{- define "kubescan.sentinelTLSSecret" -}}
{{- if and .Values.tls.existingSecret.sentinel (eq (include "kubescan.tlsMode" .) "existingSecret") -}}
{{- .Values.tls.existingSecret.sentinel -}}
{{- else -}}
kubescan-sentinel-tls
{{- end -}}
{{- end -}}

{{/*
kubescan.postgresSecret is the Secret name holding the PostgreSQL DSN.

The DSN is never rendered as a literal Deployment environment value — it
contains database credentials, and Deployment specs are readable by anyone
with `get deployment` in the namespace (defect D-04).
*/}}
{{- define "kubescan.postgresSecret" -}}
{{- if .Values.postgres.existingSecret -}}
{{- .Values.postgres.existingSecret -}}
{{- else -}}
kubescan-postgres
{{- end -}}
{{- end -}}

{{- define "kubescan.postgresSecretKey" -}}
{{- if .Values.postgres.existingSecret -}}
{{- .Values.postgres.existingSecretKey | default "dsn" -}}
{{- else -}}
dsn
{{- end -}}
{{- end -}}

{{- define "kubescan.oidcSecret" -}}
{{- if .Values.console.auth.existingSecret -}}
{{- .Values.console.auth.existingSecret -}}
{{- else -}}
kubescan-oidc
{{- end -}}
{{- end -}}

{{- define "kubescan.oidcSecretKey" -}}
{{- if .Values.console.auth.existingSecret -}}
{{- .Values.console.auth.secretKey | default "client-secret" -}}
{{- else -}}
client-secret
{{- end -}}
{{- end -}}

{{- define "kubescan.emailSecret" -}}
{{- if .Values.email.existingSecret -}}
{{- .Values.email.existingSecret -}}
{{- else -}}
kubescan-email
{{- end -}}
{{- end -}}

{{- define "kubescan.emailSecretKey" -}}
{{- if .Values.email.existingSecret -}}
{{- .Values.email.secretKey | default "api-key" -}}
{{- else -}}
api-key
{{- end -}}
{{- end -}}

{{- /*
Validate transactional email configuration in one place.

Ordered so the message names the thing an operator most likely forgot. Split
across the Deployment and the Secret, whichever Helm happened to render first
would decide the error, and a missing API key could be reported as a missing
sender.
*/ -}}
{{- define "kubescan.validateEmail" -}}
{{- if .Values.email.enabled -}}
{{- if not .Values.postgres.enabled -}}
{{- fail "email.enabled=true requires postgres.enabled=true: notifications are queued in PostgreSQL so a provider outage delays a message rather than losing it" -}}
{{- end -}}
{{- if and (not .Values.email.apiKey) (not .Values.email.existingSecret) -}}
{{- fail "email.enabled=true requires either email.apiKey or email.existingSecret" -}}
{{- end -}}
{{- if not .Values.email.from -}}
{{- fail "email.enabled=true requires email.from: the provider rejects a send with no verified sender" -}}
{{- end -}}
{{- if not .Values.email.baseURL -}}
{{- fail "email.enabled=true requires email.baseURL: links in email are absolute, and without it an invitation carries a path nobody can follow" -}}
{{- end -}}
{{- end -}}
{{- end -}}
