# CRDs shipped with the chart

Helm 3 applies everything in a chart's `crds/` directory before the templates,
which is what makes `helm install kubescan ./deployments/helm/kubescan` produce
a working deployment. Without them the controllers start, find no types to
watch, and the installation looks healthy while doing nothing — which is how it
behaved before these files existed.

These are byte-identical copies of `pkg/install/crds/`, which are themselves
generated from the Go types in `api/v1alpha1/` by controller-gen.
`TestHelm_ChartCRDsMatchTheEmbeddedCopies` fails the build if the three copies
drift, because a stale CRD is how a policy silently stops binding to its
workloads.

## Upgrades

**Helm does not upgrade CRDs.** `helm upgrade` deliberately leaves anything in
`crds/` untouched, so a chart upgrade that adds a field will not add it to the
cluster. Apply them explicitly:

```bash
kubectl apply -f deployments/helm/kubescan/crds/
```

This is Helm's behaviour, not a KubeScan choice, and it is why
`docs/runbook.md#upgrade` lists the CRD apply as its own step.
